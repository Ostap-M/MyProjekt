public interface Printable {
    void print();
}